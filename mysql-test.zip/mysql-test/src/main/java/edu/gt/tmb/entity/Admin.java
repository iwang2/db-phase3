package edu.gt.tmb.entity;

public class Admin extends User{
//	ID varchar(255) PRIMARY KEY,    
//	FOREIGN KEY(ID) REFERENCES User(ID)
//		ON DELETE CASCADE   ON UPDATE CASCADE
	//private String id;
}
